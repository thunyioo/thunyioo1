<?php
$upload_services[] = 'archive.org_member';
$max_file_size['archive.org_member'] = 2048;
$page_upload['archive.org_member'] = 'archive.org_member.php';
?>