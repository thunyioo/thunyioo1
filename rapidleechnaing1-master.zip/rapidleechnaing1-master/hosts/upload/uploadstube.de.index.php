<?php 
$upload_services[] = "uploadstube.de";
$max_file_size["uploadstube.de"] = 250;
$page_upload["uploadstube.de"] = "uploadstube.de.php";
?>