<?php
$upload_services[] = 'rodfile.com';
$max_file_size['rodfile.com'] = 2024;
$page_upload['rodfile.com'] = 'rodfile.com.php';  
?>