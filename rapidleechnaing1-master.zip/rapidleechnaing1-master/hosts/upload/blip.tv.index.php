<?php 
$upload_services[]="blip.tv";
$max_file_size["blip.tv"]=1000;
$page_upload["blip.tv"] = "blip.tv.php";
?>