<?php
$upload_services[] = 'upfile.mobi';
$max_file_size['upfile.mobi'] = 2048; // Filesize limit (MB)
$page_upload['upfile.mobi'] = 'upfile.mobi.php';
?>