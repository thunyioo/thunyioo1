<?php
$upload_services[] = 'vk.com';
$max_file_size['vk.com'] = 2000;
$page_upload['vk.com'] = 'vk.com.php';
?>