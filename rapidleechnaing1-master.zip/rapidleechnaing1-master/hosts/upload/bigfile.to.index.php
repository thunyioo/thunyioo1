<?php
$upload_services[]="bigfile.to";
$max_file_size["bigfile.to"]=5120;
$page_upload["bigfile.to"] = "bigfile.to.php";  
?>